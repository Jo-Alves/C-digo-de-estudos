from collections import namedtuple

Constants = namedtuple('Constants', ['NOME'])
constants = Constants("Desafio Python")

print(constants.NOME)
