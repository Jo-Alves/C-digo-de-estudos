print("Digite um nome")
nome = input().lower().strip()

if nome == "leandro":
  print("Encontrei o nome procurado")
  print("Encontrei o nome procurado")
  print("Encontrei o nome procurado")
  print("Encontrei o nome procurado")
  print("Encontrei o nome procurado")
elif nome == "danilo" or nome.find("danilo") != -1:
  print("Encontrei o nome procurado")
elif nome == "luciano":
  numero = int(input("Opa luciano, digite um número\n"))
  if numero == 20:
    print("Opa luciano, voce encontrou o número secreto")
  else:
    print("Opa luciano, voce não encontrou o número secreto")
else:
  print("Não encontrei o nome procurado")
  print("Não encontrei o nome procurado")
  print("Não encontrei o nome procurado")
  print("Não encontrei o nome procurado")
  print("Não encontrei o nome procurado")


# ternário



# # Java, Javascrip, C, C#
# if(nome == "leandro"){
#     print("Encontrei o nome procurado")
# }
# else{
#     print("Não encontrei o nome procurado")
# }

# # Ruby
# if nome == "leandro"
#     print("Encontrei o nome procurado")
# else
#     print("Não encontrei o nome procurado")
# end


# Operadores condicionais

# == # comparação
# > # maior
# < # menor
# >= # maior ou igual
# <= # menor ou iqual
# != # diferente


# or # ou
# and # and
