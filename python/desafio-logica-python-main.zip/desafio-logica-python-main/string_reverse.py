string = "uma palavra"
palavra = list(string)
palavra.reverse()
string = ''.join(palavra).upper()
print(string)
