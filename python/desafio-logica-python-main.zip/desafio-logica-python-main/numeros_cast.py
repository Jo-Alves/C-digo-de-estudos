inteiro = 1
resultado = 1 + inteiro

print("O resultado da operação foi", resultado)
print("O resultado da operação foi " + str(resultado))
print(f"O resultado da operação foi {resultado}")

resultado2 = 1 + int("3")
print(resultado2)

resultado3 = 1 + float("3.2")
print(resultado3)
