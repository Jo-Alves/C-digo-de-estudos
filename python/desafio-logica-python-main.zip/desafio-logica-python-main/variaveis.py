print("Digite algo na tela") # Mostre
algo = input() # le informações 
print("O valor digitado foi: " + algo) # mostrando o valor da variável na tela
print(type(algo)) # mostrando o valor da variável na tela

# ===== Tipos de dados mais utilizados =====
# str  "252351vbs1vnsdnsdsdQQQdshsds#@5221!!#$44"
# int 13213231
# float 2.5 7.9 3.0
# bool true false