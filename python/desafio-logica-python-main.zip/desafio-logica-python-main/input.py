var1 = input("1 - Forma e de utilizar o print\n")
print(var1)

b = "um dado"
c = 1
var2 = input("2 - Forma e de utilizar o print: " + "xxxx \n")
print(var2)

b = "um dado"
c = 1
var2 = input("3 - Forma e de utilizar o print: {} de {} \n".format("valor1", "valor2"))
print(var2)

# nome = "Um nome"
# x = input("3 - Forma e de utilizar o print: " + nome)

# x = input("4 - Forma e de utilizar o print: {} de {}".format("valor1", "valor2"))

# x = input("5 - Ola Sr.{1} {0}".format("Cordeiro","Leonardo"))

# x = input("6 - R$ {:7.1f}".format(1000.12))
# x = input("7 - R$ {:07.2f}".format(4.11))
# x = input(f"8 - nova forma de utilizar {var}")

