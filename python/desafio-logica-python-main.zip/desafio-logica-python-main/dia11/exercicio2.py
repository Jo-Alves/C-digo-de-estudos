"""
Utilizando o algoritimo criado no dia 10
refatore o código fazendo a persistencia dos dados
para que o cadastro de clientes, produtos e pedidos
estejam persistidos no disco
"""
# https://github.com/Jo-Alves/desafio11---python
# https://github.com/walterpaulo/logica-python/tree/main/aulas/11/exercicio2
