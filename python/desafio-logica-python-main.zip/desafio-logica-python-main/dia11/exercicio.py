"""
Dado que você aprendeu como fazer persistencia, crie um programa
para cadastro de clientes, com os campos:
Nome, email

Crei um menu para que vc possa orientar o cliente da crição e
leitura dos clientes cadastrados no disco

1 - cadastrar
2 - listar
3 - sair

"""
# https://github.com/walterpaulo/logica-python/tree/main/aulas/11/exercicio1
