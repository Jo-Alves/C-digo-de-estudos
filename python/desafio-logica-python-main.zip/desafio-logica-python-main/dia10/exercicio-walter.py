''''
Faca um programa para calcular os valores de um pedido
para isso crie um objeto dict de pedido que tenha relacao com um objeto dict de cliente

pedido = {
    "id": 1,
    "cliente": {
        "nome": "Walter"
    },
    "itens": []
}

nesse pedido, coloque uma propriedade de itens, contendo instancias de um dict de produto
no pedido, crie uma função para calcular o valor total
e uma função para mostrar um relatório do pedido, mostrando da seguinte forma:
----------------------------------------------------------------
Pedido Id: 1
Nome: João
Valor Total: R$ 999,99
----------------------------------------------------------------
O que terá no dict de pedido:
- id
- cliente
- itens []
O que terá no dict cliente:
- Nome
- email
O que terá no dict produto:
- Nome
- descrição
- preço
'''
# https://github.com/walterpaulo/logica-python/tree/main/aulas/10/exercicio
