"""
print("O resultado da operação foi", resultado)
print("O resultado da operação foi " + str(resultado))
print(f"O resultado da operação foi {resultado}")
"""

# comentário normal