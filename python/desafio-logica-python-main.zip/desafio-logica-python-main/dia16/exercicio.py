''''
Faca um programa para calcular os valores de um pedido
para isso crie uma classe de pedido que tenha relacao com uma classe de cliente

pedido = {
    "id": 1,
    "cliente": {
        "nome": "Walter"
    },
    "itens": []
}

nesse pedido, coloque uma propriedade de itens, contendo instancias de uma classe de produto
no pedido, crie um método na classe de pedido para calcular o valor total.

Na usabilidade do programa, crie um relatório mostrando da seguinte forma:
----------------------------------------------------------------
Pedido Id: 1
Nome: João
Valor Total: R$ 999,99
----------------------------------------------------------------
O que terá na classe de pedido:
- id - Autoincrement
- cliente
- itens []
O que terá na classe cliente:
- id - Autoincrement
- Nome
- email
O que terá na classe produto:
- id - Autoincrement
- Nome
- descrição
- preço

Utilize um banco de dados profissional para armazenar as informações
'''
